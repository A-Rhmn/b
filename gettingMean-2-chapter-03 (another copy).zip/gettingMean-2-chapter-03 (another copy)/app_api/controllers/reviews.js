const PoiR = require('../models/poisr');

const poisReview = (req, res) => {
    PoiR.create({
        review: req.body.review,
        poi_id: req.body.poi_id 
    })
    .then((project) =>{
        res.json(project)
    })
    .catch((err) => {
        console.log(err);
        res.sendStatus(500);
    });
};

module.exports = {
    poisReview
}