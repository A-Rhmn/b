const Poi = require('../models/pois');





const poisListByRegion = (req, res) => {
    Poi.findAll({
            where: {
                region: req.params.region
            }
        })
        .then((result) => {
            res.json(result);
        })
        .catch((err) => {
            console.log(err);
            res.sendStatus(500);
        });
};

const poisAdd = (req, res) => {
    Poi.create({
            name: req.body.name,
            type: req.body.type,
            country: req.body.country,
            region: req.body.region,
            lon: req.body.lon,
            lat: req.body.lat,
            description: req.body.description
        })
        .then((project) => {
            res.json(project)
        })
        .catch((err) => {
            console.log(err);
            res.sendStatus(500);
        });

};

const poisUpdate = (req, res) => {
    Poi.increment({
            recommendations: +1
        }, {
            where: {
                ID: req.body.ID
            }
        })
        .then((project) => {
            res.json(project)
        })
        .catch((err) => {
            console.log(err);
            res.sendStatus(500);
        });
};

module.exports = {
    poisListByRegion,
    poisAdd,
    poisUpdate
};

