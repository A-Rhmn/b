const {
    Sequelize,
    DataTypes
} = require('sequelize');

const db = require('./db');


const PoiReview = db.define('poi_reviews', {
    id: {
        type: DataTypes.INTEGER,
        autoIncrement: true,
        allowNull: false,
        primaryKey: true
    },
    poi_id: {
        type: DataTypes.INTEGER,
        references: {
            model: 'pointsOfInterest',
            referencesKey: 'ID'
        }
    },
    review: {
        type: DataTypes.TEXT
    }
}, { timestamps: false })

module.exports = PoiReview;