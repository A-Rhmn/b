const {
    Sequelize,
    DataTypes
} = require('sequelize');

const db = require('./db');

const Poi = db.define('pointsofinterest', {
    ID: {
        type: DataTypes.INTEGER,
        // To increment user_id automatically. 
        autoIncrement: true,
        // user_id can not be null. 
        allowNull: false,
        // For uniquely identifying id 
        primaryKey: true
    },

    name: {
        type: DataTypes.STRING
    },

    type: {
        type: DataTypes.STRING
    },
    country: {
        type: DataTypes.STRING
    },
    region: {
        type: DataTypes.STRING
    },
    lon: {
        type: DataTypes.FLOAT,
    },
    lat: {
        type: DataTypes.FLOAT,
    },
    description: {
        type: DataTypes.TEXT
    },
    recommendations: {
        type: DataTypes.INTEGER
    }

}, { timestamps: false, freezeTableName: true })


module.exports = Poi; 