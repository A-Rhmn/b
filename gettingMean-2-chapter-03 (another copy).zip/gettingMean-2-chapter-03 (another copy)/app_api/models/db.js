const {
  Sequelize
} = require('sequelize');

const db = new Sequelize('testdb', 'root', 'mysql', {
  host: 'localhost',
  dialect: 'mysql'
});

//----------------------------------
//const expressSession = require('express-session');
//const SessionStore = require('express-session-sequelize')(expressSession);
/*const expressSession = require('express-session');
const SessionStore = require('express-session-sequelize')(expressSession.Store);
 

// require mysql connection from external module, as per last week
//----------------------------------



try {
  db.authenticate();
  console.log('Connection has been established successfully.');
} catch (error) {
  console.error('Unable to connect to the database:', error);
}

//----------------------------------
const sequelizeSessionStore = new SessionStore({
  db: db,
});*/


/*const sequelizeSessionStore = new SessionStore({
  db: db,
});

app.use(expressSession({
    // Specify the session store to be used.
    store: sequelizeSessionStore, 

    // a secret used to digitally sign session cookie, use something unguessable (e.g. random bytes as hex) in a real application.
    secret: 'BinnieAndClyde', 

    // use as recommended by your chosen session store - related to internals of how session stores work
    resave: false, 

    // save session to store before modification
    saveUninitialized: false, 

    // reset cookie for every HTTP response. The cookie expiration time will be reset, to 'maxAge' milliseconds beyond the time of the response. 
    // Thus, the session cookie will expire after 10 mins of *inactivity* (no HTTP request made and consequently no response sent) when 'rolling' is true.
    // If 'rolling' is false, the session cookie would expire after 10 minutes even if the user was interacting with the site, which would be very
    // annoying - so true is the sensible setting.
    rolling: true, 

    // destroy session (remove it from the data store) when it is set to null, deleted etc
    unset: 'destroy', 

    // useful if using a proxy to access your server, as you will probably be doing in a production environment: this allows the session cookie to pass through the proxy
    proxy: true, 

    // properties of session cookie
    cookie: { 
        maxAge: 600000, // 600000 ms = 10 mins expiry time
        httpOnly: false // allow client-side code to access the cookie, otherwise it's kept to the HTTP messages
    }
}));*/

/*
We can use the object req.session, which is setup as soon as you have initialised your session as above. For example, 
we could use code such as: req.session.name = 'Fred Smith'; to setup
a session variable called name. This session variable could then be used by all subsequent requests, until the session is deleted. 
To end a session, we can set the session to null which, as described in the comments above, will destroy the session and remove it 
from the database: req.session = null;
*/
//----------------------------------

module.exports = db;
