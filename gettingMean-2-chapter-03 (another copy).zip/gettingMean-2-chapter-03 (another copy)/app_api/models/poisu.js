const {
    Sequelize,
    DataTypes
  } = require('sequelize'); 
  
  
const db = require('./db');

const PoiUser = db.define('poi_users', {
    id: {
        type: DataTypes.INTEGER,
        autoIncrement: true,
        allowNull: false,
        primaryKey: true
    },

    user_name: {
        type: DataTypes.STRING,
    },
    password: {
        type: DataTypes.STRING,
    }
}, {timestamps: false})

module.exports = PoiUser;