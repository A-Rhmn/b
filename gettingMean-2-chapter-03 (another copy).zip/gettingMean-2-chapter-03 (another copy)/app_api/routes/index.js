const express = require('express');
const router = express.Router();
const ctrlPois = require('../controllers/pois');
const ctrlReviews = require('../controllers/reviews');


router
  .route('/pois')
  .post(ctrlPois.poisAdd);

router
  .route('/pois/recommend/:poiid')
  .put(ctrlPois.poisUpdate);

router
  .route('/pois/region/:region')
  .get(ctrlPois.poisListByRegion);

router
  .route('/pois/review')
  .post(ctrlReviews.poisReview);

module.exports = router;
