/* GET homepage */
//const { url } = require('node:inspector');
//const L = require('leaflet');

const request = require('request');
const { db } = require('../../app_api/models/db');
const apiOptions = {
  server: 'http://localhost:3000'
};

//-----------------------------
const logIn = (req, res) => {
  if(req.body.username == 'tim' && req.body.password == 'tim123' || req.body.username == 'kate' && req.body.password == 'kate123' ) {
      req.session.username = req.body.username; 
      req.session.password = req.body.password;
      searchRegion(req, res);
  } else {
      res.status(401);
  } 
  searchRegion(req, res);
};

// Logout route
const logOut = (req, res) => {
  req.session = null;
  searchRegion(req, res);

};

//-----------------------------

const index = (req, res) => res.render('index', {
  title: 'Express '
});

const addPoi = (req, res) => {
  res.render('poisAdd', {
    title: 'a',
    head: 'Enter POI details below',
  });
}

const doAddPoi = (req, res) => {


  const path = '/api/pois';
  const postData = {
    name: req.body.name,
    type: req.body.type,
    country: req.body.country,
    region: req.body.region,
    lon: parseFloat(req.body.lon),
    lat: parseFloat(req.body.lat),
    description: req.body.description
  };

  const requestOptions = {
    url: `${apiOptions.server}${path}`,
    method: 'POST',
    json: postData
  };


  //IF NOT ALL DETAILS ENTERED, RENDER 
 /* if (req.body.display=="display") {
    if(!postData.name || !postData.type || !postData.country){
      head = "Please fill in all forms"
      reAddPoi(req, res, head);
   }else{
     head = "Submitted"
     reAddPoi(req, res, head);
   }

    
  } else {*/

    request(requestOptions, (err, response, body) => {

      if (err) {
        console.log(' \n \n \n \n \n ------------------------------------------------------------------ \n \n \n \n \n')

        //IF ERROR FROM SERVER, AND IF HTML
        if (req.body.display=="display") {
          head = "PLEASE FILL IN ALL FORMS!"
          reAddPoi(req, res, head);    
        } else  {
          //IF ERROR FROM SERVER AND MAP
          displayMap(req, res)
        }
      
      
      } else if (response.statusCode === 200) {

        //IF NO ERROR AND HTML
        if (req.body.display=="display") {
          head = "SUBMITTED"
          reAddPoi(req, res, head);
        }else{
          //IF MAP
          displayMap(req, res);
        }
      } else {
        console.log(response.statusCode);
      }
    });
 // }

};

function reAddPoi(req, res, head) {
  res.render('poisAdd', {
    title: 'FUNCTION RE ADD IS CALLED',
    head: head
  });
}




function displayMap(req, res) {
  const path = '/api/pois/region/';
  const requestOptions = {
    url: `${apiOptions.server}${path}${req.body.region}`,
    method: 'GET',
    json: {}
  };

  request(requestOptions, (err, response, body) => {

    if (err) {
      console.log(err);
    } else if (response.statusCode === 200) {
      lat = 0
        lon = 0
        num = 0
        for (i = 0; i < body.length; i++) {
          lat = lat + body[i].lat
          lon = lon + body[i].lon
          num += 1
        };
        if (num > 0) {
          avgLat = lat / num
          avgLon = lon / num
        }
          res.render('map', {
            jsonData: body,
            title: 'MAP',
            header: req.body.region,
            //AVERAGE LAT AND LON
            avgLat: avgLat,
            avgLon: avgLon,
          });
        
    } else {
      console.log(response.statusCode);
    }
  });

}

const reviewPoi = (req, res) => {

  const path = '/api/pois/review/';
  const postData = {
    review: req.body.review,
    poi_id: req.body.ID
  };
  const requestOptions = {
    url: `${apiOptions.server}${path}`,
    method: 'POST',
    json: postData
  };
  request(requestOptions, (err, response, body) => {

    if (err) {
      console.log(err);
    } else if (response.statusCode === 200) {
      displayMap(req, res);
    } else {
      console.log(response.statusCode);
    }
  });
}






const recommendPoi = (req, res) => {
  const path = '/api/pois/recommend/';
  const postData = {
    ID: req.body.ID 
  };
  const requestOptions = {
    url: `${apiOptions.server}${path}${req.body.ID}`,
    method: 'PUT',
    json: postData
  };
  request(requestOptions, (err, response, body) => {

    if (err) {
      console.log(err);
    } else if (response.statusCode === 200) {
      //IF IT UPDATES, THEN GET THE DATA FOR POILIST, WHICH, IF WORKS, WE WILL RENDER 
      const path = '/api/pois/region/';
      const requestOptions = {
        url: `${apiOptions.server}${path}${req.body.region}`,
        method: 'GET',
        json: {}
      };
      request(requestOptions, (err, response, body) => {
      
        if (err) {
          console.log(err);
        } else if (response.statusCode === 200) {
          res.render('poisList', {
            pois: body,
            title: 'Main Page',
            header: req.body.region
          });
        } else {
          console.log(response.statusCode);
        }
      });
  
    } else {
      console.log(response.statusCode);
    }
  });


}


const searchRegion = (req, res) => {
    res.render('searchRegion')
};

const doSearchRegion = (req, res) => {


  if (req.body.display == 'list') {
    const path = '/api/pois/region/';

    const requestOptions = {
      url: `${apiOptions.server}${path}${req.body.region}`,
      method: 'GET',
      json: {}
    };
    request(requestOptions, (err, response, body) => {
      
      if (err) {
        console.log(err);
      } else if (response.statusCode === 200) {
        res.render('poisList', {
          pois: body,
          title: 'Main Page',
          header: req.body.region
        });
      } else {
        console.log(response.statusCode);
      }
    });

  }
  if (req.body.display == 'map') {
    displayMap(req, res);

  }
};


module.exports = {
  logIn,
  logOut,
  reviewPoi,
  searchRegion,
  doSearchRegion,
  recommendPoi,
  addPoi,
  doAddPoi,
  index
};

