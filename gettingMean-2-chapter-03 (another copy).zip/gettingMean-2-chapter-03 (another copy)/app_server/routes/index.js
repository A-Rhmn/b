const express = require('express');
const router = express.Router();
const ctrlPois = require('../controllers/pois');


router
    .route('/')
    .get(ctrlPois.searchRegion)
    .post(ctrlPois.doSearchRegion)

router
    .route('/recommend')
    .post(ctrlPois.recommendPoi);

router
    .route('/create')
    .get(ctrlPois.addPoi)
    .post(ctrlPois.doAddPoi);

router
    .route('/review')
    .post(ctrlPois.reviewPoi);
router
    .route('/logOut')
    .get(ctrlPois.logOut);

router
    .route('/logIn')
    .post(ctrlPois.logIn);

module.exports = router;
